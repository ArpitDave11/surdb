/** @type {import('tailwindcss').Config} */
// Tokens mirror the project STYLE_BIBLE + FRAME 2.0. Use semantic names where useful,
// but arbitrary hex (text-[#374151]) is also fine per the STYLE_BIBLE convention.
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#E60028',
          hover: '#CC0024',
          dark: '#B30000',
          bg: '#FEF2F2',
          border: '#FECACA',
          tint: '#FBEAEA',
        },
        ink: '#111111',
        label: '#374151',
        muted: '#6B7280',
        hint: '#9CA3AF',
        placeholder: '#C0C0C0',
        line: { DEFAULT: '#E5E7EB', light: '#E8E8EC', faint: '#F0F0F0' },
        page: '#F7F7F8',
        sidebar: '#F9FAFB',
        ok: { DEFAULT: '#22C55E', bg: '#F0FDF4', text: '#15803D', border: '#DCFCE7' },
        warn: { DEFAULT: '#F59E0B', bg: '#FFFBEB', text: '#92400E', border: '#FEF3C7' },
        info: { DEFAULT: '#0284C7', bg: '#F0F9FF', text: '#0369A1', border: '#E0F2FE' },
        danger: '#EF4444',
      },
      fontFamily: {
        // Frutiger is the UBS brand face; graceful fallback chain.
        sans: ['Frutiger', 'Inter', 'Arial', 'Helvetica', 'sans-serif'],
        mono: ['"Roboto Mono"', '"JetBrains Mono"', 'monospace'],
      },
      borderRadius: { card: '16px' },
      boxShadow: {
        card: '0 2px 10px rgba(0,0,0,0.04)',
        active: '0 4px 16px rgba(230,0,40,0.07)',
        stat: '0 1px 4px rgba(0,0,0,0.03)',
        btn: '0 2px 6px rgba(230,0,40,0.22)',
        panel: '-4px 0 24px rgba(0,0,0,0.04)',
      },
    },
  },
  plugins: [],
};
