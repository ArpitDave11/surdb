import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  server: {
    port: 3007,
    strictPort: true,
    // When the OpenAPI team ships the real service, proxy /api here.
    // proxy: { '/api': { target: process.env.VITE_DRS_API_URL, changeOrigin: true } },
  },
});
