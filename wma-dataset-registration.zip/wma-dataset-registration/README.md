# WMA · Dataset Registration

A premium, **config-driven** intake wizard that prepopulates dataset metadata and hands off
to **DRS** (the Cirrus registration service). Designed in Figma first, built to the UBS
STYLE_BIBLE.

```bash
npm install
npm run dev        # http://localhost:3007  (mock-first; MSW intercepts DRS + refdata)
```

## Why it's easy to tune when the OpenAPI contract lands

The form is a **description, not hand-coded screens**. A contract change is a config edit,
not a rewrite.

| Layer | File | Edit when the contract changes? |
|---|---|---|
| **Field registry** (the spec) | `src/wizard/registry.ts` | ✅ add/remove/reorder sections & fields |
| **Enums** | `src/wizard/enums.ts` | ✅ catalogs, CID, zone, patterns… |
| **Renderers** (type → component) | `src/components/wizard/*`, `FieldRenderer.tsx` | ❌ never |
| **Validation** (save vs register) | `src/validation/schema.ts` | ✅ auto-derives from registry |
| **API adapter** (the seam) | `src/api/adapter.ts` | ✅ the only contract-coupled code |
| **Generated types** | `src/api/generated/` (later) | 🔄 `openapi-typescript openapi.yaml` |
| **Mock** | `src/mocks/handlers.ts` | ✅ mirrors DRS; flip `VITE_USE_MOCKS=false` for real |

**Concretely:**
- **Steps change** → reorder the `SECTIONS` array. Sidebar, hero, progress, summary all derive from it.
- **A field changes** → edit one `FieldSpec` (`{ key, label, type, required, help, api.path }`).
- **API shape shifts** → edit `serialize()/parse()` in `adapter.ts` + regenerate types. Components untouched.
- **Save vs register** → set `required: 'save' | 'register'` per field (mirrors DRS).

### One field drives everything
```ts
{ key: 'source', label: 'Source Application', type: 'appdir',
  required: 'register', prefill: 'appdir', pattern: /^[0-9A-F]{32}$/,
  help: 'AppDir ID (32 hex) — or search by business name',
  api: { path: 'drs_source' } }
```
That object renders the input, the ⓘ tooltip, the validation, the summary row, **and** tells
the adapter where it maps.

## Status
- ✅ Section 1 (Data Owner & Asset Identity) fully wired: prefill (HR + AppDir), accordion,
  validation, live summary, save-draft → mock DRS.
- ⏳ Sections 2–6 scaffolded (same engine) — drop their fields into `registry.ts` next.

## When the OpenAPI team ships the spec
1. `npx openapi-typescript openapi.yaml -o src/api/generated/schema.ts`
2. Reconcile field names + `api.path` in `registry.ts` (use the UI/DRS ↔ OpenAPI mapping).
3. Adjust transforms in `adapter.ts` if shapes differ.
4. Set `VITE_USE_MOCKS=false` and `VITE_DRS_API_BASE=<service>`.
