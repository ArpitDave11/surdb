import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

const useMocks = import.meta.env.VITE_USE_MOCKS !== 'false'; // mock-first by default

async function start() {
  if (useMocks) {
    const { worker } = await import('./mocks/browser');
    await worker.start({ onUnhandledRequest: 'bypass' });
    // eslint-disable-next-line no-console
    console.log('[MOCK] MSW intercepting DRS + refdata');
  }
  createRoot(document.getElementById('root')!).render(<App />);
}

void start();
