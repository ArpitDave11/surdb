// ─────────────────────────────────────────────────────────────────────────────
// THE REGISTRY — the working spec for the whole wizard.
//
// To change the flow:  reorder / add / remove entries in SECTIONS.
// To change a field:   edit the FieldSpec (label, type, required, help, api path…).
// When the OpenAPI team ships the contract, reconcile field names + `api.path`
// here and in api/adapter.ts — components never change.
// ─────────────────────────────────────────────────────────────────────────────
import type { SectionSpec } from './types';
import {
  CATALOGS, CONFIDENTIALITY, CID_CATEGORY, DATASET_ZONE, DATASET_TYPE,
  INFORMATION_BARRIER, OWNING_BUSINESS_ENTITY, FORMAT, FREQUENCY, SCHEMA_TYPE,
  RE_APPDIR, RE_SAC, RE_GPN, RE_SEMVER,
} from './enums';

export const SECTIONS: SectionSpec[] = [
  // ── Section 1 — fully specified (the vertical slice) ───────────────────────
  {
    id: 'identity',
    index: 1,
    eyebrow: 'New dataset registration',
    title: 'Data Owner & Asset Identity',
    description: "Confirm who owns this dataset and what it is — we've pre-filled what we can from HR and AppDir.",
    icon: 'BadgeCheck',
    layout: 'accordion',
    sidebarSubtitle: 'Owner, identity & source',
    blocks: [
      { id: 'owner', title: 'Data Owner', summaryLabel: 'Owner appointed from HR',
        fields: ['ownerGpn', 'ownerDelegateGpn', 'contactPointEmail'] },
      { id: 'identity', title: 'Dataset Identity', summaryLabel: 'Name, catalog, version & description',
        fields: ['label', 'belongsToCatalog', 'version', 'informationBarrier', 'description', 'keyword', 'requestId'] },
      { id: 'source', title: 'Source System', summaryLabel: 'Resolve from AppDir № or business name',
        fields: ['source', 'sourceComponentInstance', 'masterSource', 'owningBusinessEntity'] },
    ],
    fields: [
      // Owner
      { key: 'ownerGpn', label: 'Dataset Owner', type: 'gpn', required: 'register', prefill: 'hr',
        help: 'The accountable owner (GPN, 6–9 digits). Pre-filled from HR; change if needed.',
        pattern: RE_GPN, patternMessage: 'GPN must be 6–9 digits',
        api: { path: 'partyInRole.DatasetOwner', transform: 'partyInRole' } },
      { key: 'ownerDelegateGpn', label: 'Owner Delegate', type: 'gpn', required: false,
        help: 'Optional delegate who can act for the owner (GPN).',
        pattern: RE_GPN, patternMessage: 'GPN must be 6–9 digits',
        api: { path: 'partyInRole.DatasetOwnerDelegate', transform: 'partyInRole' } },
      { key: 'contactPointEmail', label: 'Maintainer emails', type: 'email-list', required: false,
        help: 'Contact mailbox(es). Must be @ubs.com or @credit-suisse.com.',
        api: { path: 'contactPointEmail', transform: 'emailJoin' } },

      // Identity
      { key: 'label', label: 'Dataset Name', type: 'text', required: 'save',
        placeholder: 'e.g. WMA Account Master',
        help: 'The canonical name of the dataset. No leading/trailing spaces.',
        api: { path: 'label' } },
      { key: 'belongsToCatalog', label: 'Catalog', type: 'select', required: 'save', options: CATALOGS,
        help: 'Which dataset catalog this belongs to.', default: 'wma-dataset-catalog',
        api: { path: 'belongsToCatalog' } },
      { key: 'version', label: 'Version', type: 'text', required: 'save', default: '0.0.1',
        help: 'Semantic version (x.x.x). Must be greater than the latest registered version.',
        pattern: RE_SEMVER, patternMessage: 'Use semantic version x.x.x',
        api: { path: 'version' } },
      { key: 'informationBarrier', label: 'Information Barrier', type: 'select', required: false,
        options: INFORMATION_BARRIER, help: 'Whether this dataset sits behind an information barrier.',
        api: { path: 'informationBarrier' } },
      { key: 'description', label: 'Description', type: 'textarea', required: 'register', colSpan: 2,
        placeholder: 'Describe the purpose, scope and key consumers of this dataset…',
        help: 'Required to register. A clear summary consumers can understand.',
        api: { path: 'description' } },
      { key: 'keyword', label: 'Keywords', type: 'chips', required: false, advanced: true,
        help: 'Search keywords (no spaces, ≤250 chars each).', api: { path: 'keyword', transform: 'csv' } },
      { key: 'requestId', label: 'Request IDs', type: 'chips', required: false, advanced: true,
        help: 'Associated request identifiers.', api: { path: 'requestId', transform: 'csv' } },

      // Source
      { key: 'source', label: 'Source Application', type: 'appdir', required: 'register', prefill: 'appdir',
        placeholder: 'AppDir № or business name',
        help: 'AppDir ID (32 hex chars). Search by ID or business name — each fills the other.',
        pattern: RE_APPDIR, patternMessage: 'AppDir ID must be 32 hex characters',
        api: { path: 'source' } },
      { key: 'sourceComponentInstance', label: 'Source Instance', type: 'text', required: false,
        placeholder: 'e.g. AT35700', help: 'Optional i-SAC code (AT + 4–5 digits).',
        pattern: RE_SAC, patternMessage: 'Format: AT followed by 4–5 digits',
        api: { path: 'sourceComponentInstance' } },
      { key: 'masterSource', label: 'Master Source(s)', type: 'appdir-multi', required: 'register',
        help: 'Immediate upstream source application(s). Defaults to the source application.',
        api: { path: 'masterSource' } },
      { key: 'owningBusinessEntity', label: 'Owning Business Entity', type: 'select', required: 'register',
        options: OWNING_BUSINESS_ENTITY, help: 'The business entity that owns this dataset.',
        api: { path: 'owningBusinessEntity' } },
    ],
  },

  // ── Section 2 — Entitlements (no DRS contract fields yet → not serialized) ──
  {
    id: 'entitlements', index: 2, eyebrow: 'New dataset registration', title: 'Entitlements',
    description: 'Define who may access this dataset and how access is granted and approved.',
    icon: 'Lock', layout: 'accordion', sidebarSubtitle: 'Access & permissions',
    banner: { tone: 'info', title: 'Entitlement model is being aligned with DPAS & Janus',
      body: 'Fields below are indicative — the final entitlement contract is being confirmed with the platform team.' },
    blocks: [
      { id: 'model', title: 'Entitlement Model', summaryLabel: 'How access to this dataset is granted',
        fields: ['approach', 'janusGroup', 'entitlementContact', 'eligibleRoles', 'crossDomainSharing'] },
      { id: 'rules', title: 'Access Rules & Approval', summaryLabel: 'Approval flow & restrictions',
        fields: ['approvalRules', 'fieldLevelRestrictions'] },
    ],
    fields: [
      { key: 'approach', label: 'Access approach', type: 'segmented', default: 'dpas',
        options: [{ value: 'dpas', label: 'Align to DPAS model' }, { value: 'own', label: 'Own entitlement process' }],
        colSpan: 2, help: 'Use the standard DPAS entitlement model, or run your own process.' },
      { key: 'janusGroup', label: 'Janus / BBS maintainer group', type: 'text', placeholder: 'e.g. BBS-WMA-ACCT-MASTER',
        help: 'The Janus/BBS group that maintains entitlements for this dataset.' },
      { key: 'entitlementContact', label: 'Entitlement contact', type: 'text', placeholder: 'name@ubs.com' },
      { key: 'eligibleRoles', label: 'Eligible roles', type: 'chips', colSpan: 2,
        help: 'Roles permitted to request access to this dataset.' },
      { key: 'crossDomainSharing', label: 'Cross-domain sharing', type: 'toggle', colSpan: 2,
        help: 'Allow consumers outside the owning domain to request access.' },
      { key: 'approvalRules', label: 'Approval rules', type: 'textarea', colSpan: 2,
        placeholder: 'Describe how access requests are reviewed and approved…' },
      { key: 'fieldLevelRestrictions', label: 'Field-level restrictions', type: 'text', colSpan: 2,
        placeholder: 'e.g. mask client_name for non-privileged roles' },
    ],
  },

  // ── Section 3 — Data Inputs & Outputs (distribution → structure → columns + access) ──
  {
    id: 'io', index: 3, eyebrow: 'New dataset registration', title: 'Data Inputs & Outputs',
    description: "Define the dataset's distribution — physical structure, columns, and how consumers access it.",
    icon: 'Database', layout: 'accordion', sidebarSubtitle: 'Ports & schema',
    blocks: [
      { id: 'dist', title: 'Distribution & Schema', summaryLabel: 'Physical structure & columns',
        note: { tone: 'info', title: 'Only one distribution is allowed today', body: 'The physical structure and its columns are captured below.' },
        fields: ['distFormat', 'distFrequency', 'schemaType', 'structureName', 'structurePath', 'columns'] },
      { id: 'access', title: 'Access Services', summaryLabel: 'How consumers connect',
        fields: ['accessServices'] },
    ],
    fields: [
      { key: 'distFormat', label: 'Format', type: 'select', options: FORMAT, default: 'parquet', api: { path: 'distribution.0.format' } },
      { key: 'distFrequency', label: 'Frequency', type: 'select', options: FREQUENCY, default: 'Daily', api: { path: 'distribution.0.distributionFrequency' } },
      { key: 'schemaType', label: 'Schema Type', type: 'select', options: SCHEMA_TYPE, default: 'TabularSchema', api: { path: 'distribution.0.conformsTo.type' } },
      { key: 'structureName', label: 'Structure name', type: 'text', required: 'register', default: 'Default',
        help: 'Physical data structure label (e.g. the table name).' },
      { key: 'structurePath', label: 'Path', type: 'text', placeholder: '/wma/accounts/master/' },
      { key: 'columns', label: 'Columns · physical data elements', type: 'custom', widget: 'columns-table', colSpan: 2, required: 'register' },
      { key: 'accessServices', label: 'Access services', type: 'custom', widget: 'access-services', colSpan: 2 },
    ],
  },

  // ── Section 4 — Data Agreement (classification + governance, zone→type derived) ──
  {
    id: 'agreement', index: 4, eyebrow: 'New dataset registration', title: 'Data Agreement',
    description: 'Classify the dataset, set its governance type, and attach the policies that apply.',
    icon: 'ShieldCheck', layout: 'accordion', sidebarSubtitle: 'Classification & governance',
    blocks: [
      { id: 'classification', title: 'Classification & Sensitivity', summaryLabel: 'Sensitivity tier',
        note: { tone: 'warn', title: 'Strictly Confidential is the highest tier',
          body: 'Access will require explicit approval for every consumer.' },
        fields: ['confidentialityClassification', 'clientIdentifyingDataCategory'] },
      { id: 'governance', title: 'Governance', summaryLabel: 'Type, zone & policies',
        fields: ['datasetType', 'datasetZone', 'governanceType', 'hasPolicy'] },
    ],
    fields: [
      { key: 'confidentialityClassification', label: 'Confidentiality Classification', type: 'select', required: 'register',
        options: CONFIDENTIALITY, default: 'StrictlyConfidential', api: { path: 'confidentialityClassification' } },
      { key: 'clientIdentifyingDataCategory', label: 'CID Category', type: 'select', required: 'register',
        options: CID_CATEGORY, default: 'No-CID', help: 'Client-identifying data category.', api: { path: 'clientIdentifyingDataCategory' } },
      { key: 'datasetType', label: 'Dataset Type', type: 'select', options: DATASET_TYPE, default: 'Input', api: { path: 'extension.datasetType' } },
      { key: 'datasetZone', label: 'Dataset Zone', type: 'select', options: DATASET_ZONE, default: 'Governed',
        help: 'Governed datasets get Full governance; Curated get Light.', api: { path: 'extension.datasetZone' } },
      { key: 'governanceType', label: 'Governance Type', type: 'custom', widget: 'governance-derived', colSpan: 2, api: { path: 'governanceType' } },
      { key: 'hasPolicy', label: 'Policies', type: 'chips', colSpan: 2, help: 'Policy IDs that apply to this dataset.', api: { path: 'hasPolicy', transform: 'csv' } },
    ],
  },
  { id: 'consumer', index: 5, eyebrow: 'New dataset registration', title: 'Consumer Capabilities',
    description: 'Publishing, data contracts and self-serve access for consumers — arriving in a future release.',
    icon: 'Sparkles', layout: 'coming-soon', sidebarSubtitle: '', comingSoon: true, fields: [] },
  { id: 'review', index: 6, eyebrow: 'Final step', title: 'Review & Register',
    description: "Check everything below, then register — we'll create the draft in DRS and take you straight to its screen.",
    icon: 'Send', layout: 'review', sidebarSubtitle: 'Submit to DRS', fields: [] },
];

export const sectionById = (id: string) => SECTIONS.find((s) => s.id === id);
export const fieldByKey = (section: SectionSpec, key: string) =>
  section.fields.find((f) => f.key === key);
