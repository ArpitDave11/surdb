// ─────────────────────────────────────────────────────────────────────────────
// Wizard config types — the SPEC layer.
// Steps, fields, validation, prefill and API-mapping all live as data here, so a
// change in the OpenAPI/DRS contract is a config edit, not a component rewrite.
// ─────────────────────────────────────────────────────────────────────────────

export type Values = Record<string, unknown>;

export type FieldType =
  | 'text'
  | 'textarea'
  | 'select'
  | 'segmented'
  | 'chips'        // free-text tag list (keyword, requestId)
  | 'toggle'
  | 'appdir'       // AppDir id, dual lookup (id ⇄ business name)
  | 'appdir-multi' // masterSource[]
  | 'gpn'          // 6–9 digit person id, prefilled from HR
  | 'email-list'   // contactPointEmail[]
  | 'segmented'    // mutually-exclusive button group
  | 'custom';      // rendered by a named power-widget (columns-table, access-services…)

/** When a field becomes required — mirrors DRS save-vs-register. */
export type RequiredWhen = false | 'save' | 'register';

export interface Option {
  value: string;
  label: string;
}

export interface FieldSpec {
  key: string;                 // UI state key == DRS/UI contract field name
  label: string;
  type: FieldType;
  required?: RequiredWhen;
  help?: string;               // ⓘ tooltip text (definition / what to enter)
  placeholder?: string;
  options?: Option[];          // select / segmented
  prefill?: 'hr' | 'appdir' | 'default';
  pattern?: RegExp;            // client-side format check
  patternMessage?: string;
  colSpan?: 1 | 2;
  advanced?: boolean;          // hidden behind "Add more details"
  widget?: string;             // for type:'custom' → name in widget registry
  /** Where this lands in the DRS/OpenAPI payload + how to transform. The adapter reads this. */
  api?: { path: string; transform?: 'identity' | 'partyInRole' | 'emailJoin' | 'csv' };
  default?: unknown;
}

export type BannerTone = 'info' | 'warn' | 'ok';
export interface Banner {
  tone: BannerTone;
  title: string;
  body?: string;
}

export interface SubBlock {
  id: string;
  title: string;
  summaryLabel?: string;       // shown when collapsed/done
  fields: string[];            // field keys belonging to this accordion block
  note?: Banner;               // contextual banner rendered at the top of the block body
}

export type SectionLayout = 'accordion' | 'blocks' | 'coming-soon' | 'review';

export interface SectionSpec {
  id: string;
  index: number;               // 1..N — reorder/add/remove here to change the flow
  eyebrow: string;
  title: string;
  description: string;
  icon: string;                // lucide icon name
  layout: SectionLayout;
  blocks?: SubBlock[];
  fields: FieldSpec[];
  comingSoon?: boolean;
  sidebarSubtitle: string;
  banner?: Banner;             // section-level banner (e.g. "indicative — aligning with DPAS")
}
