// DRS enum values (from the Dataset Registration API contract → common/enums.ts).
// Single source of truth for dropdowns. Swap/extend here when the contract evolves.
import type { Option } from './types';

const opt = (...vals: string[]): Option[] =>
  vals.map((v) => ({ value: v, label: v }));

export const CATALOGS = opt(
  'ib-dataset-catalog',
  'gf-dataset-catalog',
  'refdata-dataset-catalog',
  'wma-dataset-catalog',
  'am-dataset-catalog',
  'wmpc-dataset-catalog',
  'tech-dataset-catalog',
  'janus-dataset-catalog',
);

export const CONFIDENTIALITY = opt('Public', 'Internal', 'Confidential', 'StrictlyConfidential');
export const CID_CATEGORY = opt('CID-Category-A', 'CID-Category-B', 'CID-Category-C', 'CID-Category-D', 'No-CID');
export const DATASET_ZONE = opt('Curated', 'Governed');
export const DATASET_TYPE = opt('Input', 'Output', 'Technical', 'Parameter', 'Interim');
export const GOVERNANCE_TYPE = opt('Full', 'Light');
export const ENVIRONMENT_TYPE = opt('DEV', 'TEST', 'PREPROD', 'PROD', 'ENG', 'ENGTEST');
export const DATA_ORIGIN = opt('Created', 'Derived', 'PassThrough');
export const SCHEMA_TYPE = opt('TabularSchema', 'JsonSchema', 'AvroSchema', 'XsdSchema');
export const FORMAT = opt('parquet', 'delta', 'csv', 'json', 'avro', 'orc');
export const FREQUENCY = opt('RealTime', 'Daily', 'Weekly', 'Fortnightly', 'Monthly', 'Quarterly', 'HalfYearly', 'Yearly');
export const DATATYPES = opt('string', 'boolean', 'long', 'int', 'short', 'float', 'decimal', 'dateTime', 'time', 'date', 'binary', 'byte', 'integer', 'double', 'variant');
export const SERVICE_TYPES = opt('HttpDataService', 'DatabaseDataService', 'KafkaDataService', 'AdlsDataService', 'FileDataService', 'MonikerDataService', 'PowerBIDataService', 'UnityCatalogDataService');

// Indicative until refdata API confirms; safe defaults for the mock.
export const OWNING_BUSINESS_ENTITY = opt('Group Finance', 'Investment Bank', 'Global Wealth Management', 'Asset Management', 'Personal & Corporate');
export const INFORMATION_BARRIER = opt('Not behind any barrier', 'Behind information barrier');

// Derived rule: zone drives governance type (contract: governanceTypeValidation).
export const governanceTypeForZone = (zone: string | undefined): 'Full' | 'Light' | '' =>
  zone === 'Governed' ? 'Full' : zone === 'Curated' ? 'Light' : '';

// Validation patterns (contract: Validation.ts)
export const RE_APPDIR = /^[0-9A-F]{32}$/;
export const RE_SAC = /^AT\d{4,5}$/;
export const RE_GPN = /^[0-9]{6,9}$/;
export const RE_SEMVER = /^\d+\.\d+\.\d+$/;
export const EMAIL_DOMAINS = ['ubs.com', 'credit-suisse.com'];
