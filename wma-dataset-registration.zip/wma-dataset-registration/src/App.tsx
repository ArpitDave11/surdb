import { useEffect } from 'react';
import { Sidebar } from '@/components/wizard/Sidebar';
import { SummaryPanel } from '@/components/wizard/SummaryPanel';
import { Wizard } from '@/components/wizard/Wizard';
import { Header } from '@/components/wizard/Header';
import { useWizard } from '@/store/useWizard';

export default function App() {
  const prefill = useWizard((s) => s.prefill);
  useEffect(() => { void prefill(); }, [prefill]);

  return (
    <div className="flex h-screen overflow-hidden bg-page">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header />
        <main className="flex-1 overflow-y-auto">
          <Wizard />
        </main>
      </div>
      <SummaryPanel />
    </div>
  );
}
