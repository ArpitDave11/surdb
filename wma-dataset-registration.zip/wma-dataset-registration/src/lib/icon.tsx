import {
  BadgeCheck, Lock, Database, ShieldCheck, Sparkles, Send, Check, Circle,
  ChevronDown, ChevronRight, ChevronLeft, ArrowRight, ArrowUpRight,
  Info, Plus, X, Clock, Search, Lightbulb, RefreshCw, FileText, GitBranch,
  type LucideProps,
} from 'lucide-react';

const MAP: Record<string, React.ComponentType<LucideProps>> = {
  BadgeCheck, Lock, Database, ShieldCheck, Sparkles, Send, Check, Circle,
  ChevronDown, ChevronRight, ChevronLeft, ArrowRight, ArrowUpRight,
  Info, Plus, X, Clock, Search, Lightbulb, RefreshCw, FileText, GitBranch,
};

export function Icon({ name, ...props }: { name: string } & LucideProps) {
  const C = MAP[name] ?? Circle;
  return <C {...props} />;
}
