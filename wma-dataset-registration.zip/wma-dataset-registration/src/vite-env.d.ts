/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_USE_MOCKS?: string;
  readonly VITE_DRS_API_BASE?: string;
}
interface ImportMeta {
  readonly env: ImportMetaEnv;
}
