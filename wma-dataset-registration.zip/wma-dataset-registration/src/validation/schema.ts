// Validation derived from the registry. Two modes mirror DRS: 'save' (draft) needs
// little; 'register' needs the full set. Add a rule once on the FieldSpec and it
// flows into the form, the summary, and the readiness check.
import type { FieldSpec, SectionSpec, Values } from '@/wizard/types';
import { EMAIL_DOMAINS } from '@/wizard/enums';
import { SECTIONS } from '@/wizard/registry';

export type Mode = 'save' | 'register';

export function isFilled(v: unknown): boolean {
  if (Array.isArray(v)) return v.length > 0;
  if (typeof v === 'boolean') return true;
  if (v == null) return false;
  return String(v).trim().length > 0;
}

/** Pure completion count for a section — compute from `values`, never as a store selector. */
export function sectionCompletion(values: Values, sectionId: string): { filled: number; total: number } {
  const section = SECTIONS.find((s) => s.id === sectionId);
  if (!section) return { filled: 0, total: 0 };
  const fields = section.fields.filter((f) => !f.advanced);
  return { total: fields.length, filled: fields.filter((f) => isFilled(values[f.key])).length };
}

const required = (field: FieldSpec, mode: Mode): boolean =>
  field.required === 'save' || (mode === 'register' && field.required === 'register');

export function validateField(field: FieldSpec, value: unknown, mode: Mode): string | null {
  const empty = !isFilled(value);
  if (required(field, mode) && empty) return `${field.label} is required`;
  if (empty) return null;

  if (field.type === 'email-list') {
    const arr = Array.isArray(value) ? value : [value];
    for (const e of arr as string[]) {
      const dom = String(e).split('@')[1]?.toLowerCase();
      if (!dom || !EMAIL_DOMAINS.includes(dom)) return `Emails must be @${EMAIL_DOMAINS.join(' or @')}`;
    }
  }
  if (field.pattern) {
    const arr = field.type === 'appdir-multi' && Array.isArray(value) ? value : [value];
    for (const v of arr as string[]) {
      if (!field.pattern.test(String(v))) return field.patternMessage ?? `${field.label} is invalid`;
    }
  }
  return null;
}

export function validateSection(section: SectionSpec, values: Values, mode: Mode): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const field of section.fields) {
    const err = validateField(field, values[field.key], mode);
    if (err) errors[field.key] = err;
  }
  return errors;
}
