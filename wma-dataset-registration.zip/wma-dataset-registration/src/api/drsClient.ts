// Thin DRS client. Base URL is swappable: MSW intercepts in mock mode; point
// VITE_DRS_API_BASE at the real Cirrus service when the OpenAPI team ships it.
const BASE = import.meta.env.VITE_DRS_API_BASE || '/api/xportal-dr-cirrus-service/api/v3';

export interface DatasetResponse {
  id: string;
  governance?: { status: string };
  [k: string]: unknown;
}

async function req(path: string, init: RequestInit): Promise<DatasetResponse> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'content-type': 'application/json' },
    ...init,
  });
  if (!res.ok) throw new Error(`DRS ${init.method} ${path} → ${res.status}`);
  const json = await res.json();
  return (json.data ?? json) as DatasetResponse;
}

/** POST /datasets (create) or PUT /datasets/{id} (update existing draft). */
export const createDraft = (payload: Record<string, unknown>, id?: string | null) =>
  id ? req(`/datasets/${id}`, { method: 'PUT', body: JSON.stringify(payload) })
     : req('/datasets', { method: 'POST', body: JSON.stringify(payload) });

/** POST /datasets/{id}/governance-process/register */
export const registerDraft = (id: string) =>
  req(`/datasets/${id}/governance-process/register`, { method: 'POST' });
