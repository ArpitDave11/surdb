// Reference-data lookups that power systematic prefill (HR owner, AppDir source).
// These hit mock endpoints today; same shape when the real services arrive.

export interface HRPerson { gpn: string; fullName: string; email: string }
export interface AppDirApp { appId: string; name: string; businessEntity: string }

const j = async <T>(url: string): Promise<T | null> => {
  try {
    const r = await fetch(url);
    if (!r.ok) return null;
    return (await r.json()) as T;
  } catch {
    return null;
  }
};

/** Current user from HR — used to pre-appoint the dataset owner. */
export const getOwnerFromHR = () => j<HRPerson>('/refdata/me');

/** A sensible default source application for this user's area. */
export const defaultSource = () => j<AppDirApp>('/appdir/default');

/** Dual lookup: resolve by AppDir № or business name. */
export const searchAppDir = (q: string) =>
  j<AppDirApp[]>(`/appdir/search?q=${encodeURIComponent(q)}`).then((r) => r ?? []);
