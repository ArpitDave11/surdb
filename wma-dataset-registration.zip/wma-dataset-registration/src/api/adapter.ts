// ─────────────────────────────────────────────────────────────────────────────
// THE SEAM. The only contract-coupled code.
// serialize(): UI values → DRS payload (DatasetOutput).  parse(): response → UI.
// When the OpenAPI contract shifts, edit the transforms here (+ `api.path` in the
// registry) and regenerate api/generated types — components stay untouched.
//
// Transforms come straight from the DRS contract:
//   partyInRole: { DatasetOwner: "123456" }  →  [{ role, party }]
//   contactPointEmail: ["a@x","b@x"]          →  "a@x;b@x"
// ─────────────────────────────────────────────────────────────────────────────
import { SECTIONS } from '@/wizard/registry';
import type { Values } from '@/wizard/types';
import { isFilled } from '@/validation/schema';

// Set a value at a dotted path, creating objects/arrays as needed.
// 'extension.datasetType' → { extension: { datasetType } }
// 'distribution.0.format' → { distribution: [ { format } ] }
function setPath(root: Record<string, unknown>, path: string, value: unknown) {
  const parts = path.split('.');
  let node: any = root;
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    const nextIsIndex = /^\d+$/.test(parts[i + 1]);
    if (node[key] == null) node[key] = nextIsIndex ? [] : {};
    node = node[key];
  }
  node[parts[parts.length - 1]] = value;
}

export function serialize(values: Values): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  const parties: Array<{ role: string; party: string }> = [];

  for (const section of SECTIONS) {
    for (const field of section.fields) {
      if (!field.api) continue;
      const v = values[field.key];
      if (!isFilled(v)) continue;
      const t = field.api.transform ?? 'identity';

      if (t === 'partyInRole') {
        const role = field.api.path.split('.')[1]; // partyInRole.DatasetOwner → DatasetOwner
        parties.push({ role, party: String(v) });
      } else if (t === 'emailJoin') {
        setPath(out, field.api.path, Array.isArray(v) ? v.join(';') : v);
      } else {
        setPath(out, field.api.path, v); // identity / csv (array kept as-is)
      }
    }
  }
  if (parties.length) out.partyInRole = parties;
  return out;
}

// Inverse: DRS response → UI values (used when loading an existing draft).
export function parse(api: Record<string, any>): Values {
  const values: Values = {};
  for (const section of SECTIONS) {
    for (const field of section.fields) {
      if (!field.api) continue;
      const t = field.api.transform ?? 'identity';
      if (t === 'partyInRole') {
        const role = field.api.path.split('.')[1];
        const found = (api.partyInRole as Array<{ role: string; party: string }> | undefined)
          ?.find((p) => p.role === role);
        if (found) values[field.key] = found.party;
      } else if (t === 'emailJoin') {
        const raw = api[field.api.path];
        values[field.key] = typeof raw === 'string' ? raw.split(';').filter(Boolean) : raw ?? [];
      } else if (api[field.api.path] !== undefined) {
        values[field.key] = api[field.api.path];
      }
    }
  }
  return values;
}
