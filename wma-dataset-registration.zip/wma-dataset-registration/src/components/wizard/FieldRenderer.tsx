import { useWizard } from '@/store/useWizard';
import type { FieldSpec } from '@/wizard/types';
import { cn } from '@/lib/cn';
import { Search } from 'lucide-react';
import { Chip, HelpTip } from '@/components/ui/bits';
import { FieldShell, TextControl, TextareaControl, SelectControl, ChipsControl, ToggleControl, SegmentedControl } from '@/components/ui/controls';
import { WIDGETS } from './widgets';

export function FieldRenderer({ field, error }: { field: FieldSpec; error?: string }) {
  const value = useWizard((s) => s.values[field.key]);
  const setValue = useWizard((s) => s.setValue);
  const isPrefilled = useWizard((s) => s.prefilled.has(field.key));

  const required = field.required === 'save' || field.required === 'register';
  const badge = isPrefilled ? (
    <Chip tone="ok">✓ from {field.prefill === 'appdir' ? 'AppDir' : 'HR'}</Chip>
  ) : undefined;

  const str = (value ?? '') as string;
  const arr = (Array.isArray(value) ? value : []) as string[];

  // Toggles read best as a full-width row (label + help left, switch right).
  if (field.type === 'toggle') {
    return (
      <div className="sm:col-span-2">
        <div className="flex items-center gap-3 rounded-xl border border-line-faint bg-[#FCFCFD] px-4 py-3">
          <div className="flex-1">
            <span className="text-[13px] font-medium text-label">{field.label}</span>
            {field.help && <p className="text-[11.5px] text-hint">{field.help}</p>}
          </div>
          <ToggleControl checked={!!value} onChange={(v) => setValue(field.key, v)} />
        </div>
      </div>
    );
  }

  let control: React.ReactNode;
  switch (field.type) {
    case 'textarea':
      control = <TextareaControl value={str} error={error} placeholder={field.placeholder}
        onChange={(e) => setValue(field.key, e.target.value)} />;
      break;
    case 'select':
      control = <SelectControl value={str} options={field.options ?? []} error={error}
        onChange={(v) => setValue(field.key, v)} />;
      break;
    case 'chips':
    case 'email-list':
    case 'appdir-multi':
      control = <ChipsControl value={arr} error={error} placeholder={field.placeholder}
        onChange={(v) => setValue(field.key, v)} />;
      break;
    case 'segmented':
      control = <SegmentedControl value={str} options={field.options ?? []} onChange={(v) => setValue(field.key, v)} />;
      break;
    case 'custom': {
      const W = field.widget ? WIDGETS[field.widget] : undefined;
      control = W ? <W field={field} value={value} error={error} onChange={(v) => setValue(field.key, v)} /> : null;
      break;
    }
    case 'appdir':
      control = (
        <div className="flex flex-col gap-1.5">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-hint" />
            <TextControl value={str} error={error} placeholder={field.placeholder} className="pl-9"
              onChange={(e) => setValue(field.key, e.target.value)} />
          </div>
          {isPrefilled && (
            <p className="flex items-center gap-1.5 pl-0.5 text-[11.5px] text-ok-text">
              <span className="h-1.5 w-1.5 rounded-full bg-ok" /> Resolved from AppDir — review and continue
            </p>
          )}
        </div>
      );
      break;
    default: // text, gpn
      control = <TextControl value={str} error={error} placeholder={field.placeholder}
        onChange={(e) => setValue(field.key, e.target.value)} />;
  }

  return (
    <div className={cn(field.colSpan === 2 && 'sm:col-span-2')}>
      <FieldShell label={field.label} required={required} help={field.help} error={error} badge={badge}>
        {control}
      </FieldShell>
    </div>
  );
}
