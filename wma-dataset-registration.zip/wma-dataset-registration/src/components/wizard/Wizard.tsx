import { useState } from 'react';
import { SECTIONS, sectionById } from '@/wizard/registry';
import { useWizard } from '@/store/useWizard';
import { validateSection } from '@/validation/schema';
import { cn } from '@/lib/cn';
import { Hero } from './Hero';
import { NavBar } from './NavBar';
import { AccordionSection } from './AccordionSection';
import { ReviewSection } from './ReviewSection';
import { Sparkles } from 'lucide-react';

function ModeToggle() {
  const [mode, setMode] = useState<'Dataset' | 'Data Product'>('Dataset');
  return (
    <div className="flex w-full max-w-[884px]">
      <div className="inline-flex gap-1 rounded-[11px] bg-[#EEEEF1] p-1">
        {(['Dataset', 'Data Product'] as const).map((m) => (
          <button key={m} onClick={() => setMode(m)}
            className={cn('flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-[13px] transition-all focus-ring',
              mode === m ? 'bg-white font-semibold text-ink shadow-sm' : 'font-medium text-hint')}>
            {mode === m && <span className="h-[7px] w-[7px] rounded-full bg-brand" />}{m}
          </button>
        ))}
      </div>
    </div>
  );
}

function ComingSoon() {
  const feats = [
    ['Data contracts & SLAs', 'Define guarantees consumers can rely on'],
    ['Marketplace publishing', 'List this dataset in the WMA data marketplace'],
    ['Self-serve access requests', 'Let consumers request and track access'],
  ];
  return (
    <div className="flex w-full max-w-[884px] flex-col items-center gap-2 rounded-[18px] border-[1.5px] border-dashed border-line bg-[#FCFCFD] px-10 pb-8 pt-12 text-center">
      <div className="grid h-16 w-16 place-items-center rounded-[18px] bg-[#F0F2F5] text-[#8A94A6]"><Sparkles className="h-7 w-7" /></div>
      <h3 className="mt-2 text-[19px] font-semibold text-label">This section is coming soon</h3>
      <p className="max-w-[520px] text-[13px] text-hint">Consumer capabilities let downstream teams discover, contract, and request access to this dataset. We're building it now — your dataset can be registered without it.</p>
      <div className="mt-3 flex w-[560px] max-w-full flex-col gap-2.5">
        {feats.map(([t, d]) => (
          <div key={t} className="flex items-center gap-3 rounded-xl border border-line-faint bg-white px-4 py-3">
            <div className="grid h-8 w-8 place-items-center rounded-[9px] bg-[#F4F5F7] text-[#8A94A6]">◷</div>
            <div className="flex-1 text-left">
              <div className="text-[13px] font-semibold text-muted">{t}</div>
              <div className="text-[11.5px] text-[#A8AEB8]">{d}</div>
            </div>
            <span className="rounded-full bg-[#F4F5F7] px-2.5 py-1 text-[10px] font-semibold text-[#A8AEB8]">Locked</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Wizard() {
  const currentId = useWizard((s) => s.currentSectionId);
  const values = useWizard((s) => s.values);
  const goTo = useWizard((s) => s.goToSection);
  const openBlock = useWizard((s) => s.openBlock);
  const saveDraft = useWizard((s) => s.saveDraft);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const section = sectionById(currentId)!;
  const idx = SECTIONS.findIndex((s) => s.id === currentId);
  const isLast = idx === SECTIONS.length - 1;

  const onNext = () => {
    const errs = validateSection(section, values, isLast ? 'register' : 'save');
    setErrors(errs);
    if (Object.keys(errs).length) {
      const firstKey = Object.keys(errs)[0];
      const block = section.blocks?.find((b) => b.fields.includes(firstKey));
      if (block) openBlock(block.id);
      return;
    }
    if (section.fields.length) saveDraft();
    if (!isLast) goTo(SECTIONS[idx + 1].id);
  };

  return (
    <div className="flex flex-col items-center gap-5 px-8 pb-12 pt-8 lg:px-12">
      <ModeToggle />
      <Hero section={section} />
      {section.layout === 'accordion' && <AccordionSection section={section} errors={errors} />}
      {section.layout === 'coming-soon' && <ComingSoon />}
      {section.layout === 'review' && <ReviewSection />}
      {section.layout !== 'review' && <NavBar onNext={onNext} />}
    </div>
  );
}
