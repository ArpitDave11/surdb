import { SECTIONS } from '@/wizard/registry';
import { useWizard } from '@/store/useWizard';
import { isFilled, sectionCompletion } from '@/validation/schema';
import { cn } from '@/lib/cn';
import type { FieldSpec, Values } from '@/wizard/types';

const display = (field: FieldSpec, v: unknown): string => {
  if (!isFilled(v)) return '—';
  if (Array.isArray(v)) return field.type === 'email-list' || field.type === 'chips' ? v.join(', ') : `${v.length} linked`;
  return String(v);
};

function Section({ id, values }: { id: string; values: Values }) {
  const section = SECTIONS.find((s) => s.id === id)!;
  const completion = sectionCompletion(values, id);
  const current = useWizard((s) => s.currentSectionId);
  const has = completion.filled > 0;
  const rows = section.fields.filter((f) => !f.advanced && isFilled(values[f.key])).slice(0, 6);
  const showRows = id === current && rows.length > 0;

  return (
    <div className="overflow-hidden rounded-[10px] border border-line-faint bg-white">
      <div className={cn('flex items-center gap-2 px-3 py-2.5', has ? 'bg-ok-bg' : 'bg-[#FAFAFA]')}>
        <span className={cn('h-[7px] w-[7px] rounded-full', has ? 'bg-ok' : 'bg-[#D1D5DB]')} />
        <span className={cn('text-[11.5px] font-semibold', has ? 'text-ok-text' : section.comingSoon ? 'text-[#A1A1AA]' : 'text-hint')}>{section.title}</span>
        <span className="ml-auto text-[10px] font-semibold">
          {section.comingSoon ? <span className="text-[#A1A1AA]">Coming soon</span> : <span className={has ? 'text-ok' : 'text-placeholder'}>{completion.filled}/{completion.total}</span>}
        </span>
      </div>
      {showRows && (
        <div className="flex flex-col gap-2 px-3 py-3">
          {rows.map((f) => (
            <div key={f.key} className="flex items-baseline justify-between gap-3">
              <span className="shrink-0 text-[11px] text-hint">{f.label}</span>
              <span className="truncate text-right text-[11.5px] font-medium text-label">{display(f, values[f.key])}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function SummaryPanel() {
  const values = useWizard((s) => s.values);
  return (
    <aside className="flex h-full w-[320px] shrink-0 flex-col border-l border-line-light bg-white shadow-panel">
      <div className="flex items-center border-b border-line-faint px-5 py-3.5">
        <h3 className="text-[14px] font-semibold text-ink">Registration Summary</h3>
        <span className="ml-auto inline-flex items-center gap-1.5 rounded-full border border-ok-border bg-ok-bg px-2.5 py-1">
          <span className="h-1.5 w-1.5 rounded-full bg-ok" />
          <span className="text-[10.5px] font-semibold text-ok-text">Live</span>
        </span>
      </div>
      <div className="flex flex-1 flex-col gap-2.5 overflow-y-auto p-4">
        {SECTIONS.map((s) => <Section key={s.id} id={s.id} values={values} />)}
      </div>
    </aside>
  );
}
