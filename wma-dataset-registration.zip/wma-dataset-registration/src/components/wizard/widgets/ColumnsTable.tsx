import { DATATYPES, DATA_ORIGIN } from '@/wizard/enums';
import { cn } from '@/lib/cn';
import { Plus, X } from 'lucide-react';
import type { WidgetProps } from './index';

interface Col { label: string; datatypeString: string; nullable: boolean; dataOrigin: string }

const ORIGIN_TONE: Record<string, string> = {
  Created: 'bg-ok-bg text-ok-text',
  Derived: 'bg-warn-bg text-warn-text',
  PassThrough: 'bg-info-bg text-info-text',
};

export function ColumnsTable({ value, onChange }: WidgetProps) {
  const cols = (Array.isArray(value) ? value : []) as Col[];
  const patch = (i: number, p: Partial<Col>) => onChange(cols.map((c, idx) => (idx === i ? { ...c, ...p } : c)));
  const remove = (i: number) => onChange(cols.filter((_, idx) => idx !== i));
  const add = () => onChange([...cols, { label: '', datatypeString: 'string', nullable: true, dataOrigin: 'Created' }]);

  return (
    <div className="overflow-hidden rounded-xl border border-line-light">
      <div className="grid grid-cols-[1fr_150px_104px_150px_32px] items-center gap-3 border-b border-line-faint bg-[#FAFAFA] px-3.5 py-2.5">
        {['Column name', 'Data type', 'Nullable', 'Origin', ''].map((h, i) => (
          <span key={i} className="text-[9.5px] font-semibold uppercase tracking-wide text-hint">{h}</span>
        ))}
      </div>
      {cols.map((c, i) => (
        <div key={i} className="grid grid-cols-[1fr_150px_104px_150px_32px] items-center gap-3 border-b border-line-faint px-3.5 py-2 last:border-0">
          <input value={c.label} placeholder="column_name"
            onChange={(e) => patch(i, { label: e.target.value })}
            className="rounded-md border border-transparent bg-transparent px-2 py-1.5 font-mono text-[12.5px] font-medium text-ink hover:border-line focus-ring" />
          <select value={c.datatypeString} onChange={(e) => patch(i, { datatypeString: e.target.value })}
            className="cursor-pointer rounded-md bg-[#F3F4F6] px-2 py-1 font-mono text-[11px] text-muted focus-ring">
            {DATATYPES.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <button type="button" onClick={() => patch(i, { nullable: !c.nullable })}
            className="flex items-center gap-1.5 rounded-md px-1.5 py-1 hover:bg-[#F3F4F6] focus-ring">
            <span className={cn('h-1.5 w-1.5 rounded-full', c.nullable ? 'bg-placeholder' : 'bg-brand')} />
            <span className="text-[12px] font-medium text-label">{c.nullable ? 'Yes' : 'No'}</span>
          </button>
          <select value={c.dataOrigin} onChange={(e) => patch(i, { dataOrigin: e.target.value })}
            className={cn('cursor-pointer rounded-full px-2.5 py-1 text-[10.5px] font-semibold focus-ring', ORIGIN_TONE[c.dataOrigin] ?? 'bg-[#F3F4F6] text-muted')}>
            {DATA_ORIGIN.map((o) => <option key={o.value} value={o.value} className="bg-white text-ink">{o.label}</option>)}
          </select>
          <button type="button" onClick={() => remove(i)} aria-label="Remove column"
            className="grid h-6 w-6 place-items-center rounded-md text-hint hover:bg-[#F3F4F6] hover:text-danger focus-ring">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
      <button type="button" onClick={add}
        className="flex w-full items-center gap-1.5 border-t border-line-faint bg-[#FCFCFD] px-3.5 py-2.5 text-[12px] font-semibold text-brand focus-ring">
        <Plus className="h-3.5 w-3.5" /> Add column
      </button>
    </div>
  );
}
