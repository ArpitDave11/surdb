import { useEffect } from 'react';
import { useWizard } from '@/store/useWizard';
import { governanceTypeForZone } from '@/wizard/enums';
import { RefreshCw } from 'lucide-react';
import { Chip } from '@/components/ui/bits';
import type { WidgetProps } from './index';

// Governance type is DERIVED from zone (contract: governanceTypeValidation).
// The widget displays it and keeps the `governanceType` value in sync — never asked.
export function GovernanceDerived({ onChange }: WidgetProps) {
  const zone = useWizard((s) => s.values.datasetZone) as string | undefined;
  const derived = governanceTypeForZone(zone);

  useEffect(() => { onChange(derived || undefined); }, [derived]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!derived) {
    return <p className="text-[12px] text-hint">Select a dataset zone to derive the governance type.</p>;
  }
  return (
    <div className="flex items-center gap-2.5 rounded-xl border border-ok-border bg-ok-bg px-3.5 py-3">
      <span className="grid h-[22px] w-[22px] place-items-center rounded-full bg-ok-border text-ok-text">
        <RefreshCw className="h-3 w-3" />
      </span>
      <div className="flex-1">
        <p className="text-[12.5px] font-semibold text-ok-text">Governance type set to {derived}</p>
        <p className="text-[11.5px] text-[#3F9159]">Auto-derived from the {zone} zone (Curated → Light, Governed → Full).</p>
      </div>
      <Chip tone="ok">Auto</Chip>
    </div>
  );
}
