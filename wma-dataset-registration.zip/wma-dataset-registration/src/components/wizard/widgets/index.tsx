// Power-widget registry. A FieldSpec of type:'custom' names one of these by `widget`.
// Add a widget here → reference it from the registry. Keeps complex inputs out of config.
import type { FieldSpec } from '@/wizard/types';
import { ColumnsTable } from './ColumnsTable';
import { AccessServices } from './AccessServices';
import { GovernanceDerived } from './GovernanceDerived';

export interface WidgetProps {
  field: FieldSpec;
  value: unknown;
  onChange: (v: unknown) => void;
  error?: string;
}

export const WIDGETS: Record<string, React.ComponentType<WidgetProps>> = {
  'columns-table': ColumnsTable,
  'access-services': AccessServices,
  'governance-derived': GovernanceDerived,
};
