import { SERVICE_TYPES, ENVIRONMENT_TYPE } from '@/wizard/enums';
import { Plus, X } from 'lucide-react';
import { Chip } from '@/components/ui/bits';
import type { WidgetProps } from './index';

interface Service { label: string; type: string; environmentType: string; endpointUrl?: string }

// Type-specific primary field (a slice of the full DRS access-service shape).
const PRIMARY_FIELD: Record<string, { key: keyof Service; label: string; placeholder: string }> = {
  HttpDataService: { key: 'endpointUrl', label: 'Endpoint URL', placeholder: 'https://…' },
  KafkaDataService: { key: 'endpointUrl', label: 'Bootstrap server', placeholder: 'broker:9092' },
  AdlsDataService: { key: 'endpointUrl', label: 'Container / path', placeholder: 'abfss://…' },
  FileDataService: { key: 'endpointUrl', label: 'Path', placeholder: '/mnt/…' },
};

export function AccessServices({ value, onChange }: WidgetProps) {
  const services = (Array.isArray(value) ? value : []) as Service[];
  const patch = (i: number, p: Partial<Service>) => onChange(services.map((s, idx) => (idx === i ? { ...s, ...p } : s)));
  const remove = (i: number) => onChange(services.filter((_, idx) => idx !== i));
  const add = () => onChange([...services, { label: '', type: 'HttpDataService', environmentType: 'PROD', endpointUrl: '' }]);
  const sel = 'rounded-lg border border-line bg-white px-3 py-2 text-[12.5px] text-ink focus-ring cursor-pointer';

  return (
    <div className="flex flex-col gap-3">
      {services.map((s, i) => {
        const primary = PRIMARY_FIELD[s.type] ?? PRIMARY_FIELD.HttpDataService;
        return (
          <div key={i} className="rounded-xl border border-line-light bg-white p-4 shadow-card">
            <div className="mb-3 flex items-center gap-2">
              <input value={s.label} placeholder="Service label"
                onChange={(e) => patch(i, { label: e.target.value })}
                className="flex-1 rounded-md border border-transparent px-1.5 py-1 text-[13px] font-semibold text-ink hover:border-line focus-ring" />
              <Chip tone="info">{s.environmentType}</Chip>
              <button type="button" onClick={() => remove(i)} aria-label="Remove service"
                className="grid h-7 w-7 place-items-center rounded-md text-hint hover:bg-[#F3F4F6] hover:text-danger focus-ring">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <label className="flex flex-col gap-1 text-[11px] font-medium text-hint">Type
                <select value={s.type} onChange={(e) => patch(i, { type: e.target.value })} className={sel}>
                  {SERVICE_TYPES.map((o) => <option key={o.value} value={o.value}>{o.label.replace('DataService', '')}</option>)}
                </select>
              </label>
              <label className="flex flex-col gap-1 text-[11px] font-medium text-hint">Environment
                <select value={s.environmentType} onChange={(e) => patch(i, { environmentType: e.target.value })} className={sel}>
                  {ENVIRONMENT_TYPE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </label>
              <label className="flex flex-col gap-1 text-[11px] font-medium text-hint">{primary.label}
                <input value={(s[primary.key] as string) ?? ''} placeholder={primary.placeholder}
                  onChange={(e) => patch(i, { [primary.key]: e.target.value } as Partial<Service>)}
                  className="rounded-lg border border-line bg-white px-3 py-2 text-[12.5px] text-ink focus-ring" />
              </label>
            </div>
          </div>
        );
      })}
      <button type="button" onClick={add}
        className="flex items-center justify-center gap-1.5 rounded-xl border border-dashed border-line py-2.5 text-[12.5px] font-semibold text-muted hover:border-hint focus-ring">
        <Plus className="h-3.5 w-3.5" /> Add access service
      </button>
    </div>
  );
}
