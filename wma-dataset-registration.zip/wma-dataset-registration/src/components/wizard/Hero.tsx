import { useMemo, type ReactNode } from 'react';
import type { SectionSpec } from '@/wizard/types';
import { useWizard } from '@/store/useWizard';
import { SECTIONS } from '@/wizard/registry';
import { sectionCompletion, validateSection } from '@/validation/schema';

function StatCard({ num, label, sub }: { num: string; label: string; sub: string }) {
  return (
    <div className="flex-1 overflow-hidden rounded-xl border border-line-light bg-white shadow-stat">
      <div className="h-[3px] bg-brand" />
      <div className="flex flex-col gap-0.5 px-4 py-3">
        <span className="text-[22px] font-light leading-none tracking-tight text-brand">{num}</span>
        <span className="mt-1 text-[9.5px] font-semibold uppercase tracking-wide text-label">{label}</span>
        <span className="text-[10.5px] text-hint">{sub}</span>
      </div>
    </div>
  );
}

export function Hero({ section, stats }: { section: SectionSpec; stats?: ReactNode }) {
  const values = useWizard((s) => s.values);
  const completion = useMemo(() => sectionCompletion(values, section.id), [values, section.id]);
  const requiredLeft = useMemo(() => Object.keys(validateSection(section, values, 'register')).length, [values, section]);
  const saveState = useWizard((s) => s.saveState);
  const total = SECTIONS.length;
  const pct = Math.round((section.index / total) * 100);
  const idx = String(section.index).padStart(2, '0');
  const muted = section.comingSoon;

  return (
    <div className="flex w-full max-w-[884px] flex-col gap-[18px]">
      <div className="flex items-start gap-[18px]">
        <div className={`mt-0.5 h-[62px] w-1 shrink-0 rounded-sm ${muted ? 'bg-[#C7C7CC]' : 'bg-brand'}`} />
        <div className="flex flex-1 flex-col gap-[7px]">
          <div className="flex items-center gap-[7px] text-[11px] font-semibold uppercase tracking-[1px]">
            <span className={muted ? 'text-hint' : 'text-brand'}>Section {idx}</span>
            <span className="text-[#D1D5DB]">·</span>
            <span className="text-[#B0B0B0]">{section.eyebrow}</span>
          </div>
          <div className="flex items-center gap-3">
            <h1 className={`text-[30px] font-light leading-tight tracking-[-0.6px] ${muted ? 'text-muted' : 'text-ink'}`}>{section.title}</h1>
            {muted && <span className="rounded-full bg-[#EEF1F4] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-[#8A94A6]">Coming soon</span>}
          </div>
          <p className="max-w-[600px] text-[13.5px] text-muted">{section.description}</p>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[30px] font-light tracking-tight text-[#E0E0E0]">{idx}</span>
          <span className="text-[12px] font-medium text-placeholder">of {String(total).padStart(2, '0')}</span>
        </div>
      </div>

      {stats ?? (!muted && (
        <div className="flex gap-3">
          <StatCard num={`${completion.filled}/${completion.total}`} label="Fields done" sub="this section" />
          <StatCard num={requiredLeft === 0 ? 'All set' : String(requiredLeft)} label="To register" sub={requiredLeft === 0 ? 'required fields met' : 'fields still required'} />
          <StatCard num={saveState === 'saved' ? 'Saved' : 'Draft'} label={saveState === 'saved' ? 'Synced' : 'Ready to save'} sub="save & continue anytime" />
        </div>
      ))}

      <div className="h-[5px] w-full overflow-hidden rounded-full bg-[#EFEFEF]">
        <div className="h-full rounded-full bg-brand transition-all duration-500" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
