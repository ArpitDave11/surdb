import { useMemo, useState } from 'react';
import { SECTIONS } from '@/wizard/registry';
import { useWizard } from '@/store/useWizard';
import { isFilled, validateSection } from '@/validation/schema';
import { serialize } from '@/api/adapter';
import type { FieldSpec } from '@/wizard/types';
import { Button, Banner } from '@/components/ui/bits';
import { Pencil, ArrowUpRight, Check, ChevronLeft } from 'lucide-react';

const display = (f: FieldSpec, v: unknown): string => {
  if (!isFilled(v)) return '—';
  if (Array.isArray(v)) return f.type === 'chips' || f.type === 'email-list' ? `${v.length} item(s)` : `${v.length} linked`;
  return String(v);
};

function ReviewCard({ sectionId }: { sectionId: string }) {
  const section = SECTIONS.find((s) => s.id === sectionId)!;
  const values = useWizard((s) => s.values);
  const goTo = useWizard((s) => s.goToSection);
  const rows = section.fields.filter((f) => !f.advanced && f.type !== 'custom' && isFilled(values[f.key])).slice(0, 4);
  if (!rows.length) return null;
  return (
    <div className="overflow-hidden rounded-[14px] border border-line-light bg-white shadow-card">
      <div className="flex items-center border-b border-line-faint px-4 py-3">
        <span className="text-[13px] font-semibold text-ink">{section.title}</span>
        <button onClick={() => goTo(section.id)} className="ml-auto flex items-center gap-1 text-[11.5px] font-semibold text-brand focus-ring rounded">
          <Pencil className="h-3 w-3" /> Edit
        </button>
      </div>
      <div className="flex flex-col gap-2.5 px-4 py-3">
        {rows.map((f) => (
          <div key={f.key} className="flex items-baseline justify-between gap-3">
            <span className="shrink-0 text-[11.5px] text-hint">{f.label}</span>
            <span className="truncate text-right text-[12.5px] font-medium text-label">{display(f, values[f.key])}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ReviewSection() {
  const values = useWizard((s) => s.values);
  const saveDraft = useWizard((s) => s.saveDraft);
  const goTo = useWizard((s) => s.goToSection);
  const [registered, setRegistered] = useState(false);
  const prev = SECTIONS[SECTIONS.length - 2];

  const reviewable = SECTIONS.filter((s) => !s.comingSoon && s.layout !== 'review');
  const errorCount = useMemo(
    () => reviewable.reduce((n, s) => n + Object.keys(validateSection(s, values, 'register')).length, 0),
    [values, reviewable],
  );
  const ready = errorCount === 0;

  const onRegister = async () => {
    await saveDraft();
    setRegistered(true);
    // In production: registerDraft(id) then redirect to the DRS screen with the draft pre-loaded.
    // eslint-disable-next-line no-console
    console.log('[register] DRS payload', serialize(values));
  };

  return (
    <div className="flex w-full max-w-[884px] flex-col gap-5">
      <Banner tone={ready ? 'ok' : 'warn'}
        title={ready ? 'Ready to register' : `${errorCount} field${errorCount > 1 ? 's' : ''} still required`}
        body={ready ? 'All required fields are complete and valid for this dataset.' : 'Complete the highlighted fields before registering.'} />

      <div className="grid grid-cols-2 gap-4">
        {reviewable.map((s) => <ReviewCard key={s.id} sectionId={s.id} />)}
      </div>

      {/* DRS handoff */}
      <div className="overflow-hidden rounded-card border border-[#F3C9CF] bg-white shadow-active">
        <div className="flex items-center gap-3 border-b border-[#F6DADE] bg-[#FFF7F8] px-5 py-4">
          <span className="grid h-[38px] w-[38px] place-items-center rounded-[11px] border border-brand-border bg-brand-bg text-brand">
            <ArrowUpRight className="h-[18px] w-[18px]" />
          </span>
          <div className="flex-1">
            <p className="text-[14px] font-semibold text-ink">What happens when you register</p>
            <p className="text-[12px] text-hint">We hand off to DRS — the official registration system — with everything pre-filled.</p>
          </div>
          <span className="rounded-[7px] border border-[#F0DADC] bg-white px-2.5 py-1 font-mono text-[11px] font-medium text-brand-dark">Cirrus · /api/v3</span>
        </div>
        <div className="flex flex-col gap-3 px-5 py-4">
          {[
            ['1', 'Create the draft in DRS', 'POST /datasets with your dataset payload'],
            ['2', 'Open the DRS registration screen', 'pre-filled and ready — no re-keying'],
            ['3', 'Start governance in DRS', 'register → governance → approval, tracked in DRS'],
          ].map(([n, t, d]) => (
            <div key={n} className="flex items-center gap-3">
              <span className="grid h-[22px] w-[22px] place-items-center rounded-full border-[1.4px] border-[#E5C2C7] bg-white text-[11px] font-semibold text-brand">{n}</span>
              <span className="text-[13px] font-semibold text-label">{t}</span>
              <span className="text-[12px] text-hint">{d}</span>
            </div>
          ))}
        </div>
      </div>

      {registered && (
        <Banner tone="ok" title="Draft created in DRS" body="Opening the DRS registration screen with your data pre-filled…" />
      )}

      <div className="flex items-center gap-3 border-t border-line-faint pt-[18px]">
        <Button variant="secondary" onClick={() => goTo(prev.id)}><ChevronLeft className="h-3.5 w-3.5" /> Back</Button>
        <div className="flex-1" />
        <Button variant="secondary" onClick={() => saveDraft()}>Save draft</Button>
        <Button variant="primary" disabled={!ready} onClick={onRegister}>
          {registered ? <><Check className="h-3.5 w-3.5" /> Registered</> : <>Register &amp; open DRS <ArrowUpRight className="h-3.5 w-3.5" /></>}
        </Button>
      </div>
    </div>
  );
}
