import { SECTIONS } from '@/wizard/registry';
import { useWizard } from '@/store/useWizard';
import { cn } from '@/lib/cn';
import { StatusDot } from '@/components/ui/bits';

export function Sidebar() {
  const current = useWizard((s) => s.currentSectionId);
  const goTo = useWizard((s) => s.goToSection);
  const saveState = useWizard((s) => s.saveState);

  const currentIndex = SECTIONS.find((s) => s.id === current)?.index ?? 1;
  const pct = Math.round((currentIndex / SECTIONS.length) * 100);

  return (
    <aside className="flex h-full w-[280px] shrink-0 flex-col border-r border-line-light bg-sidebar px-4 pb-4 pt-5">
      {/* brand — UBS logo lockup, matched to FRAME: horizontal, centered, divider below */}
      <div className="mb-4 flex items-center gap-2.5 border-b border-line-light px-1.5 pb-4">
        <img src="/ubs-logo.png" alt="UBS" className="h-7 w-auto" />
        <span className="text-[12.5px] font-medium tracking-wide text-muted">Dataset Registration</span>
      </div>

      {/* progress */}
      <div className="flex flex-col gap-2 px-1.5 pb-4 pt-3">
        <div className="flex items-center">
          <span className="text-[11.5px] font-medium text-muted">Your progress</span>
          <span className="ml-auto text-[12.5px] font-semibold text-brand">{pct}%</span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#ECECEC]">
          <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${pct}%` }} />
        </div>
        <p className="text-[10.5px] text-hint">Section {currentIndex} of {SECTIONS.length}</p>
      </div>

      <p className="px-1.5 pb-2 text-[10px] font-semibold uppercase tracking-[0.8px] text-hint">Registration</p>

      {/* steps */}
      <nav className="flex flex-col gap-[3px]">
        {SECTIONS.map((s) => {
          const active = s.id === current;
          const done = s.index < currentIndex && !s.comingSoon;
          const soon = !!s.comingSoon;
          const state = active ? 'active' : done ? 'done' : soon ? 'soon' : 'todo';
          return (
            <button
              key={s.id} onClick={() => goTo(s.id)}
              className={cn('flex items-center gap-[11px] rounded-[10px] px-2.5 py-2.5 text-left transition-colors focus-ring',
                active ? 'bg-brand-tint' : 'hover:bg-[#F1F1F4]')}
            >
              <StatusDot state={state} n={s.index} />
              <span className="min-w-0 flex-1">
                <span className={cn('block truncate text-[12.5px]', active ? 'font-semibold text-brand-dark' : soon ? 'text-hint' : 'font-medium text-label')}>
                  {s.title}
                </span>
                {soon ? (
                  <span className="mt-0.5 flex items-center gap-1.5">
                    <span className="text-[10.5px] text-[#B0B0B0]">Coming soon</span>
                    <span className="rounded-full bg-[#EEF1F4] px-1.5 py-0.5 text-[8px] font-semibold tracking-wide text-[#8A94A6]">SOON</span>
                  </span>
                ) : (
                  <span className={cn('block truncate text-[10.5px]', active ? 'text-[#C2787F]' : 'text-hint')}>{s.sidebarSubtitle}</span>
                )}
              </span>
            </button>
          );
        })}
      </nav>

      <div className="mt-auto" />
      <div className="border-t border-[#EAEAEE] pt-3.5">
        <div className="flex items-center gap-2 rounded-[10px] border border-line-light bg-white px-2.5 py-2.5">
          <span className="text-[13px] text-ok">◷</span>
          <span className="leading-tight">
            <span className="block text-[11px] font-semibold text-label">
              {saveState === 'saved' ? 'Saved as draft' : saveState === 'saving' ? 'Saving…' : 'Not yet saved'}
            </span>
            <span className="block text-[10px] text-hint">You can finish anytime</span>
          </span>
        </div>
        <div className="mt-2.5 flex items-center px-0.5">
          <span className="text-[10.5px] text-hint">Need help with a field?</span>
          <button className="ml-auto text-[10.5px] font-semibold text-brand focus-ring rounded">Field guide</button>
        </div>
      </div>
    </aside>
  );
}
