import { sectionById } from '@/wizard/registry';
import { useWizard } from '@/store/useWizard';

export function Header() {
  const currentId = useWizard((s) => s.currentSectionId);
  const saveState = useWizard((s) => s.saveState);
  const section = sectionById(currentId)!;

  return (
    <header className="flex h-16 shrink-0 items-center border-b border-line-light bg-white pl-8 pr-7">
      <nav className="flex items-center gap-2 text-[13px]">
        <span className="text-hint">Data Products</span>
        <span className="text-placeholder">›</span>
        <span className="text-hint">New Registration</span>
        <span className="text-placeholder">›</span>
        <span className="font-medium text-ink">Section {section.index}: {section.title}</span>
      </nav>
      <div className="ml-auto flex items-center gap-3.5">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-2.5 py-1.5">
          <span className={`h-1.5 w-1.5 rounded-full ${saveState === 'saved' ? 'bg-ok' : 'bg-hint'}`} />
          <span className="text-[12px] font-medium text-muted">{saveState === 'saved' ? 'Draft saved' : saveState === 'saving' ? 'Saving…' : 'Unsaved'}</span>
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="rounded-[5px] border border-line bg-[#F3F4F6] px-1.5 py-0.5 text-[11px] font-medium text-muted">Ctrl+Enter</kbd>
          <span className="text-[12px] text-hint">to save</span>
        </span>
        <div className="flex items-center gap-2 pl-1.5">
          <div className="grid h-[30px] w-[30px] place-items-center rounded-full bg-ink text-[11px] font-semibold text-white">AD</div>
          <div className="leading-tight">
            <div className="text-[12px] font-medium text-ink">Arpit Dave</div>
            <div className="text-[10.5px] text-hint">arpit.dave@ubs.com</div>
          </div>
        </div>
      </div>
    </header>
  );
}
