import { Button } from '@/components/ui/bits';
import { ChevronLeft, ArrowRight, Loader2 } from 'lucide-react';
import { useWizard } from '@/store/useWizard';
import { SECTIONS } from '@/wizard/registry';

export function NavBar({ onNext }: { onNext: () => void }) {
  const current = useWizard((s) => s.currentSectionId);
  const goTo = useWizard((s) => s.goToSection);
  const saveDraft = useWizard((s) => s.saveDraft);
  const saveState = useWizard((s) => s.saveState);

  const idx = SECTIONS.findIndex((s) => s.id === current);
  const prev = SECTIONS[idx - 1];
  const isLast = idx === SECTIONS.length - 1;

  return (
    <div className="mt-5 flex w-full max-w-[884px] items-center gap-3 border-t border-line-faint pt-[18px]">
      <Button variant="secondary" disabled={!prev} onClick={() => prev && goTo(prev.id)}>
        <ChevronLeft className="h-3.5 w-3.5" /> Back
      </Button>
      <div className="flex-1" />
      <Button variant="secondary" onClick={() => saveDraft()} disabled={saveState === 'saving'}>
        {saveState === 'saving' ? <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Saving…</> : saveState === 'saved' ? 'Saved ✓' : 'Save draft'}
      </Button>
      <Button variant="primary" onClick={onNext}>
        {isLast ? 'Register & open DRS' : 'Next'} <ArrowRight className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
