import { useState } from 'react';
import type { SectionSpec, SubBlock } from '@/wizard/types';
import { useWizard } from '@/store/useWizard';
import { isFilled } from '@/validation/schema';
import { cn } from '@/lib/cn';
import { ChevronDown, ChevronUp, Plus } from 'lucide-react';
import { Banner, Chip, StatusDot } from '@/components/ui/bits';
import { FieldRenderer } from './FieldRenderer';

export function AccordionSection({ section, errors }: { section: SectionSpec; errors: Record<string, string> }) {
  const openBlockId = useWizard((s) => s.openBlockId);
  const openBlock = useWizard((s) => s.openBlock);
  const values = useWizard((s) => s.values);
  const prefilled = useWizard((s) => s.prefilled);

  const blockDone = (b: SubBlock) =>
    section.fields
      .filter((f) => b.fields.includes(f.key) && (f.required === 'save' || f.required === 'register'))
      .every((f) => isFilled(values[f.key]));

  const summary = (b: SubBlock): string => {
    if (b.id === 'owner' && isFilled(values.ownerGpn)) return `Owner appointed · GPN ${values.ownerGpn}`;
    if (b.id === 'identity' && isFilled(values.label)) return String(values.label);
    if (b.id === 'source' && isFilled(values.source)) return 'Source linked from AppDir';
    return b.summaryLabel ?? '';
  };

  return (
    <div className="flex w-full max-w-[884px] flex-col gap-5">
      {section.banner && <Banner tone={section.banner.tone} title={section.banner.title} body={section.banner.body} />}
      {section.blocks!.map((block, i) => {
        const open = openBlockId === block.id;
        const done = blockDone(block);
        const state = open ? 'active' : done ? 'done' : 'todo';
        const fields = block.fields.map((k) => section.fields.find((f) => f.key === k)!).filter(Boolean);
        const basic = fields.filter((f) => !f.advanced);
        const advanced = fields.filter((f) => f.advanced);
        const prefillTone = block.id === 'owner' ? 'HR' : block.id === 'source' ? 'AppDir' : null;
        const anyPrefilled = fields.some((f) => prefilled.has(f.key));

        return (
          <section key={block.id}
            className={cn('overflow-hidden rounded-card border bg-white transition-shadow',
              open ? 'border-[#F3C9CF] shadow-active' : 'border-line-light shadow-card')}>
            <button onClick={() => openBlock(block.id)}
              className="flex w-full items-center gap-3 px-5 py-4 text-left focus-ring">
              <StatusDot state={state} n={i + 1} />
              <span className="min-w-0 flex-1">
                <span className="block text-[14.5px] font-semibold text-ink">{block.title}</span>
                <span className="block truncate text-[12px] text-hint">{summary(block)}</span>
              </span>
              {done && anyPrefilled && prefillTone && <Chip tone="ok">✓ from {prefillTone}</Chip>}
              {open && <Chip tone="warn">Required</Chip>}
              {open ? <ChevronUp className="h-4 w-4 text-[#B0B0B0]" /> : <ChevronDown className="h-4 w-4 text-[#B0B0B0]" />}
            </button>

            {open && (
              <div className="flex flex-col gap-4 border-t border-line-faint px-6 py-5">
                {block.note && <Banner tone={block.note.tone} title={block.note.title} body={block.note.body} />}
                <BlockBody basic={basic} advanced={advanced} errors={errors} />
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}

function BlockBody({ basic, advanced, errors }: { basic: any[]; advanced: any[]; errors: Record<string, string> }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  return (
    <>
      <div className="grid grid-cols-1 gap-x-6 gap-y-5 sm:grid-cols-2">
        {basic.map((f) => <FieldRenderer key={f.key} field={f} error={errors[f.key]} />)}
      </div>
      {advanced.length > 0 && (
        <div className="mt-4">
          {!showAdvanced ? (
            <button onClick={() => setShowAdvanced(true)} className="flex items-center gap-1.5 text-[12.5px] font-medium text-brand focus-ring rounded">
              <Plus className="h-3.5 w-3.5" /> Add more details
              <span className="font-normal text-hint">— {advanced.map((f) => f.label.toLowerCase()).join(', ')} (optional)</span>
            </button>
          ) : (
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 sm:grid-cols-2">
              {advanced.map((f) => <FieldRenderer key={f.key} field={f} error={errors[f.key]} />)}
            </div>
          )}
        </div>
      )}
    </>
  );
}
