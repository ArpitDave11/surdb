import { useState, type ReactNode } from 'react';
import { cn } from '@/lib/cn';
import { X, ChevronDown } from 'lucide-react';
import { HelpTip } from './bits';
import type { Option } from '@/wizard/types';

const base =
  'w-full rounded-lg border bg-white px-3.5 py-2.5 text-[13px] text-ink transition-all placeholder:text-placeholder focus-ring';
const okBorder = 'border-line hover:border-placeholder';
const errBorder = 'border-danger hover:border-danger';
const inputCls = (error?: string) => cn(base, error ? errBorder : okBorder);

export function FieldShell({
  label, required, help, error, badge, children,
}: { label: string; required?: boolean; help?: string; error?: string; badge?: ReactNode; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="flex items-center gap-1.5 text-[12.5px] font-medium text-label">
        {label}
        {required && <span className="text-brand">*</span>}
        {help && <HelpTip text={help} />}
        {badge && <span className="ml-auto">{badge}</span>}
      </label>
      {children}
      {error && <p className="text-[11px] text-danger">{error}</p>}
    </div>
  );
}

export function TextControl(props: React.InputHTMLAttributes<HTMLInputElement> & { error?: string }) {
  const { error, className, ...rest } = props;
  return <input {...rest} className={cn(inputCls(error), className)} />;
}

export function TextareaControl(props: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { error?: string }) {
  const { error, className, ...rest } = props;
  return <textarea rows={3} {...rest} className={cn(inputCls(error), 'resize-y', className)} />;
}

export function SelectControl({ value, onChange, options, error }: {
  value: string; onChange: (v: string) => void; options: Option[]; error?: string;
}) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={cn(inputCls(error), 'appearance-none pr-9 cursor-pointer')}
      >
        <option value="" disabled>Select…</option>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-hint" />
    </div>
  );
}

export function ChipsControl({ value, onChange, placeholder, error }: {
  value: string[]; onChange: (v: string[]) => void; placeholder?: string; error?: string;
}) {
  const [draft, setDraft] = useState('');
  const add = () => {
    const v = draft.trim();
    if (v && !value.includes(v)) onChange([...value, v]);
    setDraft('');
  };
  return (
    <div className={cn('flex flex-wrap items-center gap-2 rounded-lg border bg-white px-2.5 py-2', error ? errBorder : okBorder)}>
      {value.map((chip) => (
        <span key={chip} className="inline-flex items-center gap-1.5 rounded-full border border-line bg-[#F3F4F6] py-1 pl-3 pr-2 text-[12px] font-medium text-label">
          <span className="max-w-[180px] truncate">{chip}</span>
          <button type="button" aria-label={`Remove ${chip}`} onClick={() => onChange(value.filter((c) => c !== chip))} className="text-hint hover:text-label focus-ring rounded-full">
            <X className="h-3 w-3" />
          </button>
        </span>
      ))}
      <input
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } }}
        onBlur={add}
        placeholder={value.length ? '' : placeholder ?? 'Type and press Enter'}
        className="min-w-[100px] flex-1 bg-transparent px-1.5 py-1 text-[13px] text-ink outline-none placeholder:text-placeholder"
      />
    </div>
  );
}

export function SegmentedControl({ value, onChange, options }: {
  value: string; onChange: (v: string) => void; options: Option[];
}) {
  return (
    <div className="inline-flex gap-1 rounded-[11px] bg-[#EEEEF1] p-1">
      {options.map((o) => {
        const active = value === o.value;
        return (
          <button key={o.value} type="button" onClick={() => onChange(o.value)}
            className={cn('flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-[12.5px] transition-all focus-ring',
              active ? 'bg-white font-semibold text-ink shadow-sm' : 'font-medium text-hint')}>
            {active && <span className="h-[7px] w-[7px] rounded-full bg-brand" />}{o.label}
          </button>
        );
      })}
    </div>
  );
}

export function ToggleControl({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button" role="switch" aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn('relative inline-flex h-[22px] w-[38px] items-center rounded-full transition-colors focus-ring', checked ? 'bg-brand' : 'bg-line')}
    >
      <span className={cn('inline-block h-4 w-4 rounded-full bg-white shadow transition-transform', checked ? 'translate-x-[18px]' : 'translate-x-[3px]')} />
    </button>
  );
}
