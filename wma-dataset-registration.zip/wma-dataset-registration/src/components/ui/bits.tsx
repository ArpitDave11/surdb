import { useState, type ReactNode } from 'react';
import { cn } from '@/lib/cn';
import { Info } from 'lucide-react';

// ── Button ──────────────────────────────────────────────────────────────────
type BtnVariant = 'primary' | 'secondary' | 'ghost';
export function Button({
  variant = 'secondary', className, children, ...props
}: { variant?: BtnVariant } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const styles: Record<BtnVariant, string> = {
    primary: 'bg-brand text-white hover:bg-brand-hover shadow-btn',
    secondary: 'bg-white text-label border border-line hover:border-hint hover:bg-[#f9fafb]',
    ghost: 'bg-transparent text-hint hover:text-label',
  };
  return (
    <button
      className={cn(
        'inline-flex items-center gap-1.5 rounded-[9px] px-4 py-2.5 text-[13px] font-medium transition-all',
        'focus-ring disabled:opacity-60 disabled:cursor-not-allowed',
        styles[variant], className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

// ── Chip / pill ─────────────────────────────────────────────────────────────
type Tone = 'neutral' | 'ok' | 'warn' | 'info' | 'brand';
const TONE: Record<Tone, string> = {
  neutral: 'bg-[#EEF1F4] text-[#8A94A6] border-transparent',
  ok: 'bg-ok-bg text-ok-text border-ok-border',
  warn: 'bg-warn-bg text-warn-text border-warn-border',
  info: 'bg-info-bg text-info-text border-info-border',
  brand: 'bg-brand-bg text-brand-dark border-brand-border',
};
export function Chip({ tone = 'neutral', className, children }: { tone?: Tone; className?: string; children: ReactNode }) {
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide', TONE[tone], className)}>
      {children}
    </span>
  );
}

// ── Info banner ─────────────────────────────────────────────────────────────
export function InfoBanner({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 rounded-xl border border-info-border bg-info-bg px-4 py-3">
      <Info className="mt-0.5 h-4 w-4 shrink-0 text-info" />
      <div>
        <p className="text-[12.5px] font-semibold text-info-text">{title}</p>
        {children && <p className="mt-0.5 text-[12px] leading-relaxed text-[#3E7CA6]">{children}</p>}
      </div>
    </div>
  );
}

// ── Tone-aware banner (section/block notes) ─────────────────────────────────
const BANNER: Record<'info' | 'warn' | 'ok', { wrap: string; icon: string; iconColor: string; title: string; body: string }> = {
  info: { wrap: 'border-info-border bg-info-bg', icon: 'ⓘ', iconColor: 'text-info', title: 'text-info-text', body: 'text-[#3E7CA6]' },
  warn: { wrap: 'border-warn-border bg-warn-bg', icon: '⚠', iconColor: 'text-warn', title: 'text-warn-text', body: 'text-warn-text/80' },
  ok: { wrap: 'border-ok-border bg-ok-bg', icon: '✓', iconColor: 'text-ok', title: 'text-ok-text', body: 'text-[#3F9159]' },
};
export function Banner({ tone, title, body }: { tone: 'info' | 'warn' | 'ok'; title: string; body?: string }) {
  const s = BANNER[tone];
  return (
    <div className={cn('flex items-start gap-2.5 rounded-xl border px-4 py-3', s.wrap)}>
      <span className={cn('mt-px text-[14px] leading-none', s.iconColor)}>{s.icon}</span>
      <div>
        <p className={cn('text-[12.5px] font-semibold', s.title)}>{title}</p>
        {body && <p className={cn('mt-0.5 text-[12px] leading-relaxed', s.body)}>{body}</p>}
      </div>
    </div>
  );
}

// ── Help tooltip (the ⓘ affordance) ─────────────────────────────────────────
export function HelpTip({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex">
      <button
        type="button"
        aria-label={text}
        className="grid h-3.5 w-3.5 place-items-center rounded-full text-placeholder hover:text-muted focus-ring"
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
      >
        <Info className="h-3.5 w-3.5" />
      </button>
      {open && (
        <span role="tooltip" className="absolute bottom-full left-1/2 z-50 mb-1.5 w-56 -translate-x-1/2 rounded-lg bg-ink px-3 py-2 text-[11.5px] font-normal leading-snug text-white shadow-lg">
          {text}
        </span>
      )}
    </span>
  );
}

// ── Status dot (stepper / accordion) ────────────────────────────────────────
export function StatusDot({ state, n }: { state: 'done' | 'active' | 'todo' | 'soon'; n?: number | string }) {
  if (state === 'done')
    return <span className="grid h-6 w-6 place-items-center rounded-full bg-ok text-[12px] font-semibold text-white">✓</span>;
  const cls =
    state === 'active' ? 'bg-brand border-brand text-white'
    : state === 'soon' ? 'bg-[#F0F0F2] border-[#F0F0F2] text-[#B0B0B0]'
    : 'bg-white border-[#DCDCE0] text-hint';
  return <span className={cn('grid h-6 w-6 place-items-center rounded-full border-[1.4px] text-[11px] font-semibold', cls)}>{n}</span>;
}
