// MSW mock — mirrors the DRS endpoints + refdata so the UI is fully working today.
// Swap to the real service by unsetting VITE_USE_MOCKS and pointing VITE_DRS_API_BASE.
import { http, HttpResponse } from 'msw';

const DRS = '*/api/xportal-dr-cirrus-service/api/v3';

let seq = 1000;

export const handlers = [
  // ── Reference data (prefill) ──
  http.get('*/refdata/me', () =>
    HttpResponse.json({ gpn: '123456', fullName: 'Jane Smith', email: 'jane.smith@ubs.com' }),
  ),
  http.get('*/appdir/default', () =>
    HttpResponse.json({ appId: '0123456789ABCDEF0123456789ABCDEF', name: 'ACME Core', businessEntity: 'Group Finance' }),
  ),
  http.get('*/appdir/search', ({ request }) => {
    const q = new URL(request.url).searchParams.get('q')?.toLowerCase() ?? '';
    const apps = [
      { appId: '0123456789ABCDEF0123456789ABCDEF', name: 'ACME Core', businessEntity: 'Group Finance' },
      { appId: 'FEDCBA9876543210FEDCBA9876543210', name: 'WMA Ledger', businessEntity: 'Global Wealth Management' },
      { appId: 'AAAA1111BBBB2222CCCC3333DDDD4444', name: 'Risk Hub', businessEntity: 'Investment Bank' },
    ].filter((a) => a.name.toLowerCase().includes(q) || a.appId.toLowerCase().includes(q));
    return HttpResponse.json(apps);
  }),

  // ── DRS dataset draft ──
  http.post(`${DRS}/datasets`, async ({ request }) => {
    const body = (await request.json()) as Record<string, unknown>;
    const id = `00000000-0000-0000-0000-${String(seq++).padStart(12, '0')}`;
    return HttpResponse.json({
      data: { ...body, id, revision: 1, governance: { status: 'Draft' }, createdAt: new Date().toISOString() },
    });
  }),
  http.put(`${DRS}/datasets/:id`, async ({ params, request }) => {
    const body = (await request.json()) as Record<string, unknown>;
    return HttpResponse.json({ data: { ...body, id: params.id, governance: { status: 'Draft' } } });
  }),
  http.post(`${DRS}/datasets/:id/governance-process/register`, ({ params }) =>
    HttpResponse.json({ data: { id: params.id, governance: { status: 'Registered' } } }),
  ),
];
