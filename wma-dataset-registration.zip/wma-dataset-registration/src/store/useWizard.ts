import { create } from 'zustand';
import { SECTIONS } from '@/wizard/registry';
import type { Values } from '@/wizard/types';
import { isFilled } from '@/validation/schema';
import { createDraft } from '@/api/drsClient';
import { serialize } from '@/api/adapter';
import { getOwnerFromHR, defaultSource } from '@/api/refdata';

type SaveState = 'idle' | 'saving' | 'saved' | 'error';

interface WizardState {
  values: Values;
  currentSectionId: string;
  openBlockId: string | null;     // which accordion block is expanded
  prefilled: Set<string>;         // keys filled by HR/AppDir (for the "from HR" badge)
  draftId: string | null;
  saveState: SaveState;
  savedAt: string | null;

  setValue: (key: string, value: unknown) => void;
  setValues: (patch: Values) => void;
  goToSection: (id: string) => void;
  openBlock: (id: string | null) => void;
  prefill: () => Promise<void>;
  saveDraft: () => Promise<void>;
  completion: (sectionId: string) => { filled: number; total: number };
}

// Seed defaults from the registry so fields with defaults are populated up front.
const defaults: Values = {};
for (const s of SECTIONS) for (const f of s.fields) if (f.default !== undefined) defaults[f.key] = f.default;

export const useWizard = create<WizardState>((set, get) => ({
  values: {
    ...defaults,
    masterSource: [], keyword: [], requestId: [], contactPointEmail: [],
    eligibleRoles: ['Data Analyst', 'Risk Officer', 'Auditor', 'Data Steward'],
    hasPolicy: ['POL-WMA-ACCT-001', 'POL-RETENTION-7Y'],
    columns: [
      { label: 'account_id', datatypeString: 'string', nullable: false, dataOrigin: 'Created' },
      { label: 'client_name', datatypeString: 'string', nullable: true, dataOrigin: 'PassThrough' },
      { label: 'balance_amount', datatypeString: 'decimal', nullable: true, dataOrigin: 'Derived' },
      { label: 'opened_date', datatypeString: 'date', nullable: true, dataOrigin: 'Created' },
    ],
    accessServices: [
      { label: 'Default', type: 'HttpDataService', environmentType: 'PREPROD', endpointUrl: 'https://wma.ubs.net/api/accounts' },
    ],
  },
  currentSectionId: SECTIONS[0].id,
  openBlockId: 'identity',
  prefilled: new Set<string>(),
  draftId: null,
  saveState: 'idle',
  savedAt: null,

  setValue: (key, value) => set((st) => ({ values: { ...st.values, [key]: value }, saveState: 'idle' })),
  setValues: (patch) => set((st) => ({ values: { ...st.values, ...patch } })),
  goToSection: (id) => set({
    currentSectionId: id,
    openBlockId: SECTIONS.find((s) => s.id === id)?.blocks?.[0]?.id ?? null,
  }),
  openBlock: (id) => set((st) => ({ openBlockId: st.openBlockId === id ? null : id })),

  prefill: async () => {
    const [owner, src] = await Promise.all([getOwnerFromHR(), defaultSource()]);
    const patch: Values = {};
    const filled = new Set(get().prefilled);
    if (owner) {
      patch.ownerGpn = owner.gpn;
      patch.contactPointEmail = [owner.email];
      filled.add('ownerGpn'); filled.add('contactPointEmail');
    }
    if (src) {
      patch.source = src.appId;
      patch.masterSource = [src.appId];
      patch.owningBusinessEntity = src.businessEntity;
      filled.add('source'); filled.add('masterSource'); filled.add('owningBusinessEntity');
    }
    set((st) => ({ values: { ...st.values, ...patch }, prefilled: filled }));
  },

  saveDraft: async () => {
    set({ saveState: 'saving' });
    try {
      const payload = serialize(get().values);
      const res = await createDraft(payload, get().draftId);
      set({ draftId: res.id, saveState: 'saved', savedAt: new Date().toISOString() });
    } catch (e) {
      console.error('[saveDraft]', e);
      set({ saveState: 'error' });
    }
  },

  completion: (sectionId) => {
    const section = SECTIONS.find((s) => s.id === sectionId);
    if (!section) return { filled: 0, total: 0 };
    const fields = section.fields.filter((f) => !f.advanced);
    const values = get().values;
    return {
      total: fields.length,
      filled: fields.filter((f) => isFilled(values[f.key])).length,
    };
  },
}));
